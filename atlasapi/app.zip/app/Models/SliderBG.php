<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class SliderBG extends Model
{
    protected $fillable = [
        'name', 'use'];
}
