<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class BuyController extends Controller
{
    public function __construct()
    {
        header('Access-Control-Allow-Origin:  *');
        header('Access-Control-Allow-Headers:  Content-Type, X-Auth-Token, Authorization, Origin');
        header('Access-Control-Allow-Methods:  GET, POST, PUT');
    }
    public function index(Request $request)
    {
        print_r($request->input('mobile'));

        // if ($request->hasFile('image')) {
        //     $image = $request->file('image');
        //     $destinationPath = public_path('images/client_uploads');
        //     $file_name = '1.jpg';
        //     $image->move($destinationPath,$file_name);
        // }
    }

    public function uploadImage(Request $request)
    {
        $mobile = $request->input('mobile');
        if ($request->hasFile('image')) {
            $image = $request->file('image');
            $destinationPath = public_path('images/client_uploads');
            $file_name = $request->file('image')->getClientOriginalName();;
            $image->move($destinationPath,$file_name);
        }
    }
}
