<?php

namespace App\Http\Controllers;

use App\Models\Address;
use App\Models\City;
use App\Models\Province;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Redis;
use Kavenegar;

class AuthController extends Controller
{
    public function __construct()
    {
        header('Access-Control-Allow-Origin:  *');
        header('Access-Control-Allow-Headers:  Content-Type, X-Auth-Token, Authorization, Origin');
        header('Access-Control-Allow-Methods:  GET, POST, PUT');
        // $this->middleware('auth:api', ['except' => ['login','register']]);

    }

    public function generatePassword(Request $request)
    {
        $mobile = $request->input('mobile');

        // // first check if mobile exist or not if not exist create one
        if (User::where('mobile', $mobile)->count() == 0)
            DB::table('users')->insert(['mobile' => $mobile]);


        $user = User::where('mobile', $mobile)->first();
        $user->disposablePassword = random_int(1000, 9999);
        $user->save();
        $this->sendGeneratePassSms($user->disposablePassword, $mobile);
        return $user->disposablePassword;
    }

    public function login(Request $request)
    {
        $mobile = $request->mobile;
        $password = $request->password;

        $user = User::where('mobile', $mobile)->where('disposablePassword', $password);

        //  if wrong password return
        if ($user->count() === 0)
            return response()->json([], 403);

        $user = $user->first();

        // // if it is the first time user loged in it generate token
        if (!$user->token) {
            $user->token = Hash::make($mobile . $password . now());
            $user->save();
        }
        return $user->token;
    }

    public function userInfo(Request $request)
    {
        $user = User::where('token', $request->input('token'))->select('created_at', 'email', 'fname', 'id', 'lname', 'mobile', 'updated_at', 'token')->first();
        return $user;
    }

    public function getProvinces()
    {
        $provinces = Province::all();
        foreach ($provinces as $key => $province) {
            $provinces[$key]['cities'] = $province->cities;
        }

        return $provinces;
    }

    public function editUser(Request $request)
    {
        $input = $request->all();
        print_r($input);
        $user = User::where('token', $input['token'])->first();
        $user->fname = $input['fname'];
        $user->lname = $input['lname'];
        $user->email = isset($input['email']) ? $input['email'] : null;
        $user->save();

        $address = [
            'user_id' => $user->id,
            'province_id' => $input['province'],
            'city_id'=> $input['city'],
            'address' => $input['address']
        ];

        Address::create($address);
    }
    public function sendGeneratePassSms($password, $mobile)
    {
        try {
            $sender = "10001000900088";
            $message = $password . ' کد ورود شما به پازل فریم ';
            $receptor = array($mobile);
            $result = Kavenegar::Send($sender, $receptor, $message);
            // if ($result) {
            //     foreach ($result as $r) {
            //         echo "messageid = $r->messageid";
            //         echo "message = $r->message";
            //         echo "status = $r->status";
            //         echo "statustext = $r->statustext";
            //         echo "sender = $r->sender";
            //         echo "receptor = $r->receptor";
            //         echo "date = $r->date";
            //         echo "cost = $r->cost";
            //     }
            // }
        } catch (\Kavenegar\Exceptions\ApiException $e) {
            // در صورتی که خروجی وب سرویس 200 نباشد این خطا رخ می دهد
            echo $e->errorMessage();
        } catch (\Kavenegar\Exceptions\HttpException $e) {
            // در زمانی که مشکلی در برقرای ارتباط با وب سرویس وجود داشته باشد این خطا رخ می دهد
            echo $e->errorMessage();
        }
    }
}
