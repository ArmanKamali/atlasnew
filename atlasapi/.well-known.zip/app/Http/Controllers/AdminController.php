<?php

namespace App\Http\Controllers;

use App\Models\Admin;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;

class AdminController extends Controller
{
    public function __construct()
    {
        header('Access-Control-Allow-Origin:  *');
        header('Access-Control-Allow-Headers:  Content-Type, X-Auth-Token, Authorization, Origin');
        header('Access-Control-Allow-Methods:  GET, POST, PUT');
        // $this->middleware('auth:api', ['except' => ['login','register']]);

    }
    public function login(Request $request)
    {
        $email = $request->input('email');
        $password = $request->input('password');
        $user = Admin::where('email', $email)->where('password', $password)->first();
        //    for first time entering
        if (!$user->token) {
            $user->token = Hash::make($email . $password . now());
            $user->save();
        }

        return $user->token;
    }
}
